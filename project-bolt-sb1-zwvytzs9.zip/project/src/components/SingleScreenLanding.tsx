import {
  ShieldCheck,
  BadgeCheck,
  ClipboardCheck,
  Search,
  ShoppingCart,
  UserRound,
  Users,
  Store,
  ArrowRight,
} from 'lucide-react';

const STEPS = [
  {
    icon: ClipboardCheck,
    number: 1,
    body: 'Выберите аллергии в профиле.',
    accent: 'bg-safe-50 text-safe-600',
  },
  {
    icon: Search,
    number: 2,
    body: 'Найдите продукт в поиске.',
    accent: 'bg-caution-50 text-caution-600',
  },
  {
    icon: ShoppingCart,
    number: 3,
    body: 'Закажите безопасное.',
    accent: 'bg-danger-50 text-danger-600',
  },
];

export default function SingleScreenLanding() {
  return (
    <main className="flex h-[100dvh] w-full justify-center overflow-hidden bg-white p-2">
      <div className="grid h-full w-full max-w-md grid-cols-2 grid-rows-[auto_minmax(0,1fr)] gap-2 md:max-w-6xl md:grid-rows-[auto_minmax(0,1fr)] md:gap-2.5">
        {/* Hero */}
        <section className="col-span-2 flex flex-col justify-center rounded-2xl bg-neutral-100 p-3.5 md:p-5">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-white md:h-8 md:w-8">
              <ShieldCheck className="h-4 w-4 text-safe-500" strokeWidth={2} />
            </div>
            <p className="text-[10px] font-semibold uppercase tracking-wider text-neutral-400 md:text-[11px]">
              SafeBite
            </p>
          </div>
          <div className="mt-2 grid items-center gap-3 md:grid-cols-[1.4fr_1fr]">
            <div>
              <h1 className="text-[1.15rem] font-bold leading-[1.15] tracking-tight text-neutral-900 md:text-[1.5rem] lg:text-[1.8rem]">
                Безопасная еда без риска аллергии за 1&nbsp;секунду
              </h1>
              <p className="mt-1 text-[11.5px] leading-[1.35] text-neutral-500 md:mt-2 md:text-[14px]">
                Умный поиск товаров с автоматической индикацией опасных ингредиентов.
              </p>
            </div>
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2 rounded-xl bg-white p-2 md:p-3">
                <BadgeCheck className="h-4 w-4 shrink-0 text-safe-600" strokeWidth={2} />
                <p className="text-[10.5px] leading-[1.3] text-neutral-700 md:text-[12px]">
                  100% автопроверка состава по профилю аллергенов.
                </p>
              </div>
              <button
                type="button"
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-neutral-900 py-2 text-[13px] font-semibold text-white transition-transform duration-150 active:scale-[0.98] md:py-2.5 md:text-sm"
              >
                Начать поиск
                <ArrowRight className="h-4 w-4" strokeWidth={2} />
              </button>
            </div>
          </div>
        </section>

        {/* How it works */}
        <section className="flex min-h-0 flex-col rounded-2xl bg-neutral-100 p-2.5 md:p-4">
          <h2 className="text-[11px] font-bold tracking-tight text-neutral-900 md:text-[15px]">Как это работает</h2>
          <div className="mt-1.5 flex min-h-0 flex-1 flex-col justify-center gap-1 md:gap-1.5">
            {STEPS.map((step) => (
              <div key={step.number} className="flex items-center gap-1.5 rounded-lg bg-white p-1.5 md:gap-2.5 md:rounded-xl md:p-2.5">
                <div className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md md:h-7 md:w-7 md:rounded-lg ${step.accent}`}>
                  <step.icon className="h-3 w-3 md:h-3.5 md:w-3.5" strokeWidth={2} />
                </div>
                <p className="text-[10px] leading-[1.25] text-neutral-700 md:text-[12px]">
                  <span className="font-semibold text-neutral-900">Шаг {step.number}. </span>
                  {step.body}
                </p>
              </div>
            ))}
          </div>
          <div className="mt-1.5 flex items-center justify-center gap-1 rounded-full bg-white py-1 md:gap-1.5 md:py-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-safe-500" />
            <span className="h-1.5 w-1.5 rounded-full bg-caution-500" />
            <span className="h-1.5 w-1.5 rounded-full bg-danger-500" />
            <span className="ml-0.5 text-[9px] font-medium text-neutral-500 md:ml-1 md:text-[10px]">
              Цветовой рейтинг товара
            </span>
          </div>
        </section>

        {/* Right column: for whom + pricing */}
        <div className="grid min-h-0 grid-rows-[auto_minmax(0,1fr)] gap-2 md:gap-2.5">
          <section className="rounded-2xl bg-neutral-100 p-2.5 md:p-4">
            <div className="flex items-center gap-1.5 md:gap-2">
              <div className="flex h-5 w-5 items-center justify-center rounded-md bg-white md:h-7 md:w-7 md:rounded-lg">
                <UserRound className="h-3 w-3 text-neutral-900 md:h-3.5 md:w-3.5" strokeWidth={2} />
              </div>
              <h2 className="text-[11px] font-bold tracking-tight text-neutral-900 md:text-[15px]">Для кого</h2>
            </div>
            <p className="mt-1 text-[10px] leading-[1.3] text-neutral-700 md:mt-1.5 md:text-[12px]">
              Для студентки Анны с острой аллергией на лесные орехи и лактозу, которая уставшая выбирает еду в магазинах у дома.
            </p>
          </section>

          <section className="flex min-h-0 flex-col rounded-2xl bg-neutral-100 p-2.5 md:p-4">
            <h2 className="text-[11px] font-bold tracking-tight text-neutral-900 md:text-[15px]">Сколько стоит</h2>
            <div className="mt-1.5 grid min-h-0 flex-1 grid-cols-2 gap-1.5">
              <div className="flex flex-col justify-center rounded-lg bg-white p-1.5 md:rounded-xl md:p-2.5">
                <div className="flex items-center gap-1">
                  <Users className="h-3 w-3 text-safe-600 md:h-3.5 md:w-3.5" strokeWidth={2} />
                  <p className="text-[9px] font-semibold text-neutral-700 md:text-[11px]">Покупателям</p>
                </div>
                <p className="text-sm font-bold tracking-tight text-neutral-900 md:text-[1.25rem]">0 ₽</p>
                <p className="text-[8.5px] leading-[1.2] text-neutral-500 md:text-[10px]">Бесплатно, всегда.</p>
              </div>
              <div className="flex flex-col justify-center rounded-lg bg-white p-1.5 md:rounded-xl md:p-2.5">
                <div className="flex items-center gap-1">
                  <Store className="h-3 w-3 text-neutral-900 md:h-3.5 md:w-3.5" strokeWidth={2} />
                  <p className="text-[9px] font-semibold text-neutral-700 md:text-[11px]">Магазинам</p>
                </div>
                <p className="text-sm font-bold tracking-tight text-neutral-900 md:text-[1.25rem]">5%</p>
                <p className="text-[8.5px] leading-[1.2] text-neutral-500 md:text-[10px]">Комиссия за заказ.</p>
              </div>
            </div>
          </section>
        </div>
      </div>
    </main>
  );
}
