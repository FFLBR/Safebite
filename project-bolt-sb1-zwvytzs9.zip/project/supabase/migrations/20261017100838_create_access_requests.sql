/*
# Create access_requests table

1. New Tables
- `access_requests` — заявки на ранний доступ с промо-лендинга SafeBite.
- `id` (uuid, primary key) — идентификатор заявки.
- `name` (text, not null) — имя посетителя из формы.
- `email` (text, not null) — email посетителя из формы.
- `created_at` (timestamptz, default now()) — время отправки формы.
2. Security
- Enable RLS on `access_requests`.
- Allow anon + authenticated INSERT only (форма на лендинге работает без входа).
- No SELECT/UPDATE/DELETE policies: посетители не могут читать чужие заявки или менять их;
  просмотр заявок выполняется владельцем проекта через привилегированное подключение.
3. Notes
- Single-tenant promo landing: no auth, no user_id column.
- Duplicate emails are allowed (a person may submit twice); the owner deduplicates offline.
*/

CREATE TABLE IF NOT EXISTS access_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE access_requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_insert_access_requests" ON access_requests;

CREATE POLICY "anon_insert_access_requests"
ON access_requests FOR INSERT
TO anon, authenticated
WITH CHECK (true);
